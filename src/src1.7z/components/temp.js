<nav className="navbar navbar-expand-lg navbar-light bg-light">
<div className="collapse navbar-collapse" id="navbarNav">
    <ul className="navbar-nav navList">
        <li className="nav-item">工作室列表
            {/* <Link className="nav-link" to="">工作室列表</Link> */}                    
        </li>
        <li className="nav-item">遊戲列表
            {/* <Link className="nav-link" to="">遊戲列表</Link> */}                    
        </li>
        <li className="nav-item">本月主打
            {/* <Link className="nav-link" to="">本月主打</Link> */}                    
        </li>
        <li className="nav-item">密室地圖
            {/* <Link className="nav-link" to="">本月主打</Link> */}                    
        </li>
        <li className="nav-item">揪團一起玩
            {/* <Link className="nav-link" to="">本月主打</Link> */}                    
        </li>
    </ul>
</div>
</nav>