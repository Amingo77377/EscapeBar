import React, {Component} from 'react';
import './body.scss';

class Body extends Component{
    constructor(props){
        super(props)
    }

    render(){
        return(
            <React.Fragment>
                <div >
                    <div id="search">
                        <div id="search-area">
                            
                        </div>
                    </div>
                </div>
                
            </React.Fragment>
        )
    }
}
export default Body;