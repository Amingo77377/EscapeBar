import React,{Component} from 'react';
import './pro_map.scss';

class PRO_MAP extends Component{
    constructor(props){
        super(props)
        this.state = {

        }

    }
    componentDidUpdate(){
        
    }

    render(){
        return(
            <React.Fragment>
                <div id="pro_map">
                    {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3615.0961465805754!2d121.46791231495854!3d25.030810983973847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3442a841b904711f%3A0x7393cf50dd19029e!2zMjIw5paw5YyX5biC5p2_5qmL5Y2A5ZCz6bOz6LevNTDlt7c3NeW8hDjomZ8x!5e0!3m2!1szh-TW!2stw!4v1542183601476" frameborder="0" style={{border:0}} allowfullscreen></iframe> */}
                </div>
            </React.Fragment>
        )
    }


}

export default PRO_MAP;