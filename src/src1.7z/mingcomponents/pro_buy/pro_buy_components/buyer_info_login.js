import React, {Component} from 'react'
import './buyer_info_login.scss'

class BuyerInfoLogin extends Component {
  constructor(props){
    super(props)
    
  }

  render(){
    return(
      <React.Fragment>
        <div id="pro_flow">
       
        </div>
      </React.Fragment>
    )
  }
}


export default BuyerInfoLogin