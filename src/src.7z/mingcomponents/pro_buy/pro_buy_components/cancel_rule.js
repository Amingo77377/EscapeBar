import React, {Component} from 'react'
import './cancel_rule.scss'

class CancelRule extends Component {
  constructor(props){
    super(props)
    
  }

  render(){
    return(
      <React.Fragment>
        <div id="pro_flow">
       
        </div>
      </React.Fragment>
    )
  }
}


export default CancelRule