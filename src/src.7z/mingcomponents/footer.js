import React, {Component} from 'react';

class Footer extends Component{
    constructor(props){
        super(props)
    }

    render(){
        return(
            <React.Fragment>
                <h1>footer</h1>
                
            </React.Fragment>
        )
    }
}
export default Footer;