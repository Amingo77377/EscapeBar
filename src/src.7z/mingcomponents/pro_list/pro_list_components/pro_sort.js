// import React, {Component} from 'react';
// import './pro_sort.scss';


// class ProSort extends Component{
//   constructor(props){
//     super(props)
//     this.state = {

//     }

//   }
//   componentDidUpdate(){
        
//   }

//   render(){
//     return(
//       <React.Fragment>
//         <div id="pro_sort">
//           <div className="w15"><h4>排序方式</h4></div>
//           <div className="w85">
//             <div>排序依據: </div>
//             <div>評價星級: </div>
//             <div>價格排序: </div>
//           </div>
//         </div>
//       </React.Fragment>
//     )
//   }


// }

// export default ProSort;